export type CafLink = { key: string; name: string; region?: string; url: string };

export const APPROVED_BY_UNI: Record<string, CafLink[]> = {
  polimi: [
    { key:"cisl", name:"CAF CISL", region:"Lombardia", url:"https://prenotazioni.cafcisl.it/" },
    { key:"acli", name:"CAF ACLI (myCAF)", url:"https://www.cafacli.it/it/mycaf/" },
    { key:"cgil", name:"CAAF CGIL Lombardia", url:"https://www.assistenzafiscale.info/prenota-online/" }
  ],
  sapienza: [
    { key:"cisl", name:"CAF CISL", region:"Lazio", url:"https://www.cafcisllazio.it/prenota-appuntamento.html" },
    { key:"acli", name:"CAF ACLI (myCAF)", url:"https://areapersonale.mycaf.it/myCAF20/?p=prenotazione" }
  ]
};