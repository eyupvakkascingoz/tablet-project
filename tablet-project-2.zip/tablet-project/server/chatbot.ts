import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT
// Using blueprint: javascript_gemini
// Gemini model series: gemini-2.5-flash

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface ChatbotResponse {
  text: string;
  actions?: Array<{
    label: string;
    path: string;
    icon?: string;
  }>;
}

// Bureaucracy knowledge base for the chatbot
const BUREAUCRACY_CONTEXT = `
You are DocuBot, a helpful assistant for international students in Italy. You help them with bureaucratic processes AND guide them to use the DocuBuddy+ app features.

**IMPORTANT APP FEATURES YOU CAN RECOMMEND:**
1. ROOMMATE FINDER (/roommates) - For finding compatible roommates based on lifestyle, budget, and preferences
2. BUREAUCRACY MANAGER (/bureaucracy) - For managing ISEE, Permesso di Soggiorno, Codice Fiscale, SPID processes
3. DOCUMENT ANALYSIS (/bureaucracy) - For AI-powered document type detection and validation
4. CALENDAR/REMINDERS (/calendar) - For tracking important deadlines
5. COMMUNITY BOARD (/community) - For connecting with other students

**Key Bureaucratic Information:**
- Permesso di Soggiorno: Residence permit required for non-EU students. Must apply within 8 days of arrival.
- Codice Fiscale: Tax code needed for most bureaucratic procedures. Get it from Agenzia delle Entrate.
- ISEE: Income certificate needed for university benefits and scholarships.
- SPID: Digital identity system for accessing Italian government services online.
- Tessera Sanitaria: Health card obtained after registering with local ASL.
- CAF: Tax assistance centers that help with ISEE and other documents.

**WHEN TO SUGGEST APP FEATURES:**
- If user asks about finding roommates, housing, or accommodation → Suggest /roommates
- If user asks about ISEE, permits, documents, or bureaucracy → Suggest /bureaucracy
- If user asks about deadlines or reminders → Suggest /calendar
- If user wants to connect with students → Suggest /community

**RESPONSE FORMAT:**
When suggesting an app feature, end your response with this exact format:
ACTION: {"path": "/roommates", "label": "Find Roommates"}
or
ACTION: {"path": "/bureaucracy", "label": "Manage Documents"}

Only include ONE action per response, the most relevant one.

Answer in the same language the user asks the question. Support Italian, English, Turkish, and Arabic.
Be concise, friendly, and helpful.
`;

export async function askChatbot(userMessage: string, language: string = 'en'): Promise<ChatbotResponse> {
  try {
    if (!process.env.GEMINI_API_KEY) {
      const errorMsg = language === 'it' ? 'Bot non configurato. API key mancante.' :
                       language === 'tr' ? 'Bot yapılandırılmadı. API anahtarı eksik.' :
                       language === 'ar' ? 'لم يتم تكوين البوت. مفتاح API مفقود.' :
                       'Bot not configured. API key missing.';
      return { text: errorMsg };
    }

    const prompt = `${BUREAUCRACY_CONTEXT}\n\nUser question (in ${language}): ${userMessage}\n\nProvide a helpful answer in ${language}:`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    const fullText = response.text || "I couldn't generate a response. Please try again.";
    
    // Parse action from response
    const actionMatch = fullText.match(/ACTION:\s*({[^}]+})/);
    let text = fullText;
    let actions = undefined;
    
    if (actionMatch) {
      try {
        const actionData = JSON.parse(actionMatch[1]);
        text = fullText.replace(/ACTION:\s*{[^}]+}/, '').trim();
        actions = [actionData];
      } catch (e) {
        // If parsing fails, just use the full text
      }
    }

    return { text, actions };
  } catch (error) {
    console.error('Chatbot error:', error);
    const errorMsg = language === 'it' ? 'Errore. Riprova.' :
                     language === 'tr' ? 'Hata oluştu. Tekrar deneyin.' :
                     language === 'ar' ? 'حدث خطأ. حاول مرة أخرى.' :
                     'Error occurred. Please try again.';
    return { text: errorMsg };
  }
}
