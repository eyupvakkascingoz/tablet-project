import { Link } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Users, Calendar, MessageCircle, HelpCircle, Settings, Briefcase } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export default function Home() {
  const { language } = useLanguage();
  const t = useTranslation(language);

  const features = [
    {
      title: t('bureaucracy'),
      description: t('bureaucracyDesc'),
      icon: FileText,
      path: '/bureaucracy',
      gradient: 'from-cyan-50 to-primary/10',
      iconBg: 'from-cyan-400 to-primary',
    },
    {
      title: t('roommates'),
      description: t('roommatesDesc'),
      icon: Users,
      path: '/roommates',
      gradient: 'from-cyan-50 to-teal-50',
      iconBg: 'from-cyan-500 to-teal-500',
    },
    {
      title: t('calendar'),
      description: t('calendarDesc'),
      icon: Calendar,
      path: '/calendar',
      gradient: 'from-teal-50 to-cyan-50',
      iconBg: 'from-teal-400 to-cyan-400',
    },
    {
      title: t('chat'),
      description: t('chatDesc'),
      icon: MessageCircle,
      path: '/chat',
      gradient: 'from-cyan-50 to-blue-50',
      iconBg: 'from-cyan-500 to-blue-500',
    },
    {
      title: t('communityBoard'),
      description: t('communityBoardDesc'),
      icon: HelpCircle,
      path: '/community',
      gradient: 'from-blue-50 to-cyan-50',
      iconBg: 'from-blue-400 to-cyan-400',
    },
    {
      title: t('settings'),
      description: t('settingsDesc'),
      icon: Settings,
      path: '/settings',
      gradient: 'from-cyan-50 to-teal-50',
      iconBg: 'from-cyan-400 to-teal-400',
    },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-b from-cyan-50 via-white to-primary/5">
      <div className="container mx-auto px-4 py-12 md:py-20">
        <div className="text-center mb-12 md:mb-16 animate-in fade-in duration-700">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-cyan-500 via-primary to-cyan-600 bg-clip-text text-transparent">
            {t('appName')}
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto animate-in slide-in-from-bottom duration-500">
            {t('tagline')}
          </p>
        </div>

        {/* CAF Search - Featured Section */}
        <div className="mb-16 max-w-4xl mx-auto animate-in slide-in-from-bottom duration-700">
          <Card className="overflow-hidden border-2 border-cyan-200 shadow-xl hover:shadow-2xl transition-all duration-300 bg-gradient-to-br from-cyan-50 to-white">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400 to-primary flex items-center justify-center shadow-lg">
                    <Briefcase className="w-8 h-8 text-white" />
                  </div>
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-2xl md:text-3xl font-bold mb-2 bg-gradient-to-r from-cyan-600 to-primary bg-clip-text text-transparent">
                    {language === 'it' ? 'Cerca Appuntamenti CAF' : 
                     language === 'tr' ? 'CAF Randevu Ara' :
                     language === 'ar' ? 'البحث عن مواعيد CAF' :
                     'CAF Appointment Search'}
                  </h2>
                  <p className="text-muted-foreground">
                    {language === 'it' ? 'Trova e prenota appuntamenti CAF vicino a te per ISEE, assistenza fiscale e altro' :
                     language === 'tr' ? 'ISEE, vergi yardımı ve daha fazlası için yakınınızdaki CAF randevularını bulun ve ayırtın' :
                     language === 'ar' ? 'ابحث واحجز مواعيد CAF بالقرب منك لـ ISEE والمساعدة الضريبية والمزيد' :
                     'Find and book CAF appointments near you for ISEE, tax assistance, and more'}
                  </p>
                </div>
                <Link href="/bureaucracy">
                  <Button 
                    size="lg" 
                    className="bg-gradient-to-r from-cyan-500 to-primary hover:from-cyan-600 hover:to-primary/90 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 active:scale-95 px-8"
                  >
                    {language === 'it' ? 'Trova CAF' :
                     language === 'tr' ? 'CAF Bul' :
                     language === 'ar' ? 'ابحث عن CAF' :
                     'Find CAF'} →
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {features.map(({ title, description, icon: Icon, path, gradient, iconBg }, index) => (
            <Link key={path} href={path} data-testid={`link-${path.slice(1)}`}>
              <Card 
                className={`h-full cursor-pointer bg-gradient-to-br ${gradient} border-cyan-100 hover:border-cyan-300 transition-all duration-300 hover:shadow-xl hover:scale-105 active:scale-95 animate-in fade-in slide-in-from-bottom`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardHeader className="text-center pb-4">
                  <div className={`mx-auto mb-4 p-4 rounded-full bg-gradient-to-br ${iconBg} w-fit shadow-md`}>
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl bg-gradient-to-r from-cyan-700 to-primary bg-clip-text text-transparent">{title}</CardTitle>
                  <CardDescription className="text-base mt-2">
                    {description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center pb-6">
                  <span className="text-sm font-medium bg-gradient-to-r from-cyan-600 to-primary bg-clip-text text-transparent">
                    {t('getStarted')} →
                  </span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
