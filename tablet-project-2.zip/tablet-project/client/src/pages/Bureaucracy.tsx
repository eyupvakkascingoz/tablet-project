import BureaucracyFlow from '@/components/BureaucracyFlow';
import DocumentAnalysis from '@/components/DocumentAnalysis';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export default function Bureaucracy() {
  const { language } = useLanguage();
  const t = useTranslation(language);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">{t('bureaucracy')}</h1>
        <p className="text-muted-foreground">{t('bureaucracyDesc')}</p>
      </div>

      <div className="mb-8">
        <DocumentAnalysis />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        <BureaucracyFlow flowType="codiceFiscale" />
        <BureaucracyFlow flowType="firstPermesso" />
        <BureaucracyFlow flowType="permesso" />
        <BureaucracyFlow flowType="tesseraSanitaria" />
        <BureaucracyFlow flowType="cartaIdentita" />
        <BureaucracyFlow flowType="prenotazioneVisita" />
        <BureaucracyFlow flowType="medicoBase" />
        <BureaucracyFlow flowType="anagrafe" />
        <BureaucracyFlow flowType="patente" />
        <BureaucracyFlow flowType="universita" />
        <BureaucracyFlow flowType="isee" />
        <BureaucracyFlow flowType="dsu" />
        <BureaucracyFlow flowType="spid" />
      </div>
    </div>
  );
}
