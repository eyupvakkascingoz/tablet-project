import { LanguageProvider } from '@/contexts/LanguageContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { Toaster } from '@/components/ui/toaster';
import BureaucracyFlow from '../BureaucracyFlow';

export default function BureaucracyFlowExample() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <div className="p-8 space-y-6">
          <BureaucracyFlow flowType="isee" />
          <BureaucracyFlow flowType="permesso" />
          <BureaucracyFlow flowType="spid" />
        </div>
        <Toaster />
      </LanguageProvider>
    </ThemeProvider>
  );
}
