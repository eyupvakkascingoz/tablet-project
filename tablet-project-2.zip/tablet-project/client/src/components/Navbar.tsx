import { Link, useLocation } from 'wouter';
import { Moon, Sun, FileText, Users, Calendar, MessageSquare, Settings as SettingsIcon, HelpCircle, Briefcase, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/contexts/ThemeContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation, type Language } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const languageFlags: Record<Language, string> = {
  en: '🇬🇧',
  it: '🇮🇹',
  tr: '🇹🇷',
  ar: '🇸🇦',
};

const languageNames: Record<Language, string> = {
  en: 'English',
  it: 'Italiano',
  tr: 'Türkçe',
  ar: 'العربية',
};

export default function Navbar() {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();

  const handleOnlineCAF = () => {
    toast({
      title: t('onlineCaf'),
      description: t('onlineCafComingSoon'),
    });
  };

  const navItems = [
    { path: '/', label: t('home'), emoji: '🏠', icon: Home, type: 'link' },
    { path: '/bureaucracy', label: t('bureaucracy'), emoji: '📋', icon: FileText, type: 'link' },
    { path: '/roommates', label: t('roommates'), emoji: '🏡', icon: Users, type: 'link' },
    { path: '/community', label: t('communityBoard'), emoji: '💬', icon: HelpCircle, type: 'link' },
    { path: '/chat', label: t('chat'), emoji: '🤖', icon: MessageSquare, type: 'link' },
    { path: '', label: t('onlineCaf'), emoji: '💼', icon: Briefcase, type: 'button', onClick: handleOnlineCAF },
    { path: '/calendar', label: t('reminders'), emoji: '📅', icon: Calendar, type: 'link' },
    { path: '/settings', label: t('settings'), emoji: '⚙️', icon: SettingsIcon, type: 'link' },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b-2 border-cyan-200 bg-gradient-to-r from-cyan-50 via-white to-cyan-50 backdrop-blur-lg supports-[backdrop-filter]:bg-white/90 shadow-lg">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 active:scale-95 hover:bg-cyan-50" data-testid="link-home">
          <div className="relative p-2 rounded-xl bg-gradient-to-br from-cyan-500 to-teal-500 shadow-lg">
            <FileText className="h-7 w-7 text-white" />
          </div>
          <span className="text-2xl font-extrabold bg-gradient-to-r from-cyan-600 via-teal-500 to-cyan-500 bg-clip-text text-transparent drop-shadow-sm">{t('appName')}</span>
        </Link>

        <div className="hidden md:flex items-center gap-2">
          {navItems.map(({ path, label, emoji, icon: Icon, type, onClick }) => (
            type === 'button' ? (
              <Button
                key={label}
                variant="outline"
                size="default"
                className="gap-2 border-2 border-cyan-300 hover:border-cyan-500 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-teal-50 transition-all duration-300 hover:scale-110 active:scale-95 hover:shadow-lg px-4"
                onClick={onClick}
                data-testid="button-online-caf"
              >
                <span className="text-lg">{emoji}</span>
                <span className="font-medium">{label}</span>
              </Button>
            ) : (
              <Link key={path} href={path} data-testid={`link-${path.slice(1)}`}>
                <Button
                  variant={location === path ? 'default' : 'outline'}
                  size="default"
                  className={`gap-2 border-2 transition-all duration-300 hover:scale-110 active:scale-95 shadow-sm px-4 ${
                    location === path 
                      ? 'bg-gradient-to-r from-cyan-500 to-teal-500 border-cyan-400 shadow-lg shadow-cyan-500/30' 
                      : 'border-cyan-300 hover:border-cyan-500 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-teal-50 hover:shadow-lg'
                  }`}
                >
                  <span className="text-lg">{emoji}</span>
                  <span className="font-medium">{label}</span>
                </Button>
              </Link>
            )
          ))}
        </div>

        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-2" data-testid="button-language">
                <span>{languageFlags[language]}</span>
                <span className="hidden sm:inline">{languageNames[language]}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {(Object.keys(languageFlags) as Language[]).map((lang) => (
                <DropdownMenuItem
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  className="gap-2"
                  data-testid={`button-language-${lang}`}
                >
                  <span>{languageFlags[lang]}</span>
                  <span>{languageNames[lang]}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
          >
            {theme === 'light' ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5" />
            )}
          </Button>
        </div>
      </div>

      <div className="md:hidden border-t-2 border-cyan-200 bg-gradient-to-r from-cyan-50 via-white to-cyan-50 shadow-md">
        <div className="container mx-auto px-4 py-3 flex gap-2 overflow-x-auto">
          {navItems.map(({ path, label, emoji, icon: Icon, type, onClick }) => (
            type === 'button' ? (
              <Button
                key={label}
                variant="outline"
                size="default"
                className="gap-2 whitespace-nowrap border-2 border-cyan-300 hover:border-cyan-500 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-teal-50 transition-all duration-300 hover:shadow-lg px-4"
                onClick={onClick}
                data-testid="button-mobile-online-caf"
              >
                <span className="text-lg">{emoji}</span>
                <span className="font-medium">{label}</span>
              </Button>
            ) : (
              <Link key={path} href={path} data-testid={`link-mobile-${path.slice(1)}`}>
                <Button
                  variant={location === path ? 'default' : 'outline'}
                  size="default"
                  className={`gap-2 whitespace-nowrap border-2 transition-all duration-300 shadow-sm px-4 ${
                    location === path 
                      ? 'bg-gradient-to-r from-cyan-500 to-teal-500 border-cyan-400 shadow-lg shadow-cyan-500/30' 
                      : 'border-cyan-300 hover:border-cyan-500 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-teal-50 hover:shadow-lg'
                  }`}
                >
                  <span className="text-lg">{emoji}</span>
                  <span className="font-medium">{label}</span>
                </Button>
              </Link>
            )
          ))}
        </div>
      </div>
    </nav>
  );
}
