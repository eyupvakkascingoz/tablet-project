import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Upload, X, Search } from 'lucide-react';
import RoommateCard, { type RoommateProfile } from '@/components/RoommateCard';
import RoomListingCard, { type RoomListing } from '@/components/RoomListingCard';
import MapModal from '@/components/MapModal';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const demoProfiles: RoommateProfile[] = [
  {
    id: '1',
    name: 'Maria Rossi',
    city: 'Milan',
    university: 'Politecnico di Milano',
    budgetMin: 400,
    budgetMax: 600,
    pets: false,
    smoker: false,
    cleanliness: 5,
    noiseTolerance: 3,
  },
  {
    id: '2',
    name: 'Ahmed Hassan',
    city: 'Rome',
    university: 'Sapienza University',
    budgetMin: 350,
    budgetMax: 500,
    pets: true,
    smoker: false,
    cleanliness: 4,
    noiseTolerance: 4,
  },
  {
    id: '3',
    name: 'Sophie Martin',
    city: 'Milan',
    university: 'Bocconi University',
    budgetMin: 500,
    budgetMax: 700,
    pets: false,
    smoker: false,
    cleanliness: 4,
    noiseTolerance: 2,
  },
];

const demoListings: RoomListing[] = [
  {
    id: '1',
    title: 'Cozy Room in City Center',
    description: 'Bright room in shared apartment, close to metro station. Fully furnished with wifi.',
    city: 'Milan',
    rentPrice: 450,
    locationUrl: 'https://www.google.com/maps/place/Milan,+Metropolitan+City+of+Milan,+Italy/@45.4668,9.1905,11z',
    ownerName: 'Giulia Bianchi',
    smoking: 'notAllowed',
    pets: 'allowed',
    furnished: 'yes',
    genderPreference: 'none',
    deposit: 900,
    billsIncluded: true,
  },
  {
    id: '2',
    title: 'Student Room Near University',
    description: 'Perfect for students! Walking distance to Sapienza University. Shared kitchen and living room.',
    city: 'Rome',
    rentPrice: 380,
    locationUrl: 'https://www.google.com/maps/place/Rome,+Metropolitan+City+of+Rome,+Italy/@41.9028,12.4964,11z',
    ownerName: 'Marco Russo',
    smoking: 'notAllowed',
    pets: 'notAllowed',
    furnished: 'yes',
    genderPreference: 'female',
    deposit: 380,
    billsIncluded: false,
  },
];

export default function Roommates() {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();

  const [profile, setProfile] = useState<Partial<RoommateProfile>>({
    city: '',
    university: '',
    budgetMin: 300,
    budgetMax: 600,
    pets: false,
    smoker: false,
    cleanliness: 3,
    noiseTolerance: 3,
  });

  const [matches, setMatches] = useState<RoommateProfile[]>([]);
  const [showDemo, setShowDemo] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const [listings, setListings] = useState<RoomListing[]>(() => {
    const saved = localStorage.getItem('roomListings');
    return saved ? JSON.parse(saved) : demoListings;
  });
  
  const [newListing, setNewListing] = useState<Partial<RoomListing>>({
    title: '',
    description: '',
    city: '',
    rentPrice: 0,
    locationUrl: '',
    ownerName: '',
    photos: [],
    smoking: 'notAllowed',
    pets: 'notAllowed',
    furnished: 'yes',
    genderPreference: 'none',
    deposit: 0,
    billsIncluded: false,
  });

  const [selectedListing, setSelectedListing] = useState<RoomListing | null>(null);
  const [showMapModal, setShowMapModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const calculateMatch = (other: RoommateProfile): number => {
    let score = 0;
    
    if (profile.city === other.city) score += 20;
    
    const budgetOverlap = Math.min(profile.budgetMax || 0, other.budgetMax) - 
                          Math.max(profile.budgetMin || 0, other.budgetMin);
    if (budgetOverlap > 0) score += 15;
    
    if (profile.pets === other.pets) score += 10;
    if (profile.smoker === other.smoker) score += 10;
    
    const cleanDiff = Math.abs((profile.cleanliness || 3) - other.cleanliness);
    score += Math.max(0, 20 - cleanDiff * 4);
    
    const noiseDiff = Math.abs((profile.noiseTolerance || 3) - other.noiseTolerance);
    score += Math.max(0, 20 - noiseDiff * 4);
    
    return Math.min(100, Math.round(score));
  };

  const handleSaveProfile = () => {
    localStorage.setItem('roommateProfile', JSON.stringify(profile));
    toast({
      title: t('saveProfile'),
      description: t('profileSavedSuccessfully'),
    });
  };

  const handlePreviewDemo = () => {
    setShowDemo(!showDemo);
  };

  const handleFindMatches = () => {
    if (!profile.city) {
      toast({
        title: 'Profile Incomplete',
        description: 'Please select a city',
        variant: 'destructive',
      });
      return;
    }

    const matchedProfiles = demoProfiles
      .map(p => ({ ...p, matchPercentage: calculateMatch(p) }))
      .sort((a, b) => (b.matchPercentage || 0) - (a.matchPercentage || 0));
    
    setMatches(matchedProfiles);
    setShowDemo(false);
    
    toast({
      title: t('findMatches'),
      description: `${t('foundMatches')} ${matchedProfiles.length} ${t('matches_count')}`,
    });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const currentPhotos = newListing.photos || [];
    const remainingSlots = 8 - currentPhotos.length;
    
    if (remainingSlots <= 0) {
      toast({
        title: t('uploadPhotos'),
        description: 'Maximum 8 photos allowed',
        variant: 'destructive',
      });
      return;
    }

    const fileArray = Array.from(files).slice(0, remainingSlots);
    const photoPromises = fileArray.map(file => {
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
    });

    Promise.all(photoPromises).then(photos => {
      setNewListing({ ...newListing, photos: [...currentPhotos, ...photos] });
    });
  };

  const handleSaveListing = () => {
    if (!newListing.title || !newListing.city || !newListing.rentPrice || !newListing.ownerName) {
      toast({
        title: 'Listing Incomplete',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const listing: RoomListing = {
      id: Date.now().toString(),
      title: newListing.title!,
      description: newListing.description || '',
      city: newListing.city!,
      rentPrice: newListing.rentPrice!,
      locationUrl: newListing.locationUrl,
      ownerName: newListing.ownerName!,
      photos: newListing.photos || [],
      smoking: newListing.smoking || 'notAllowed',
      pets: newListing.pets || 'notAllowed',
      furnished: newListing.furnished || 'yes',
      genderPreference: newListing.genderPreference || 'none',
      deposit: newListing.deposit || 0,
      billsIncluded: newListing.billsIncluded || false,
    };

    const updatedListings = [...listings, listing];
    setListings(updatedListings);
    localStorage.setItem('roomListings', JSON.stringify(updatedListings));

    setNewListing({
      title: '',
      description: '',
      city: '',
      rentPrice: 0,
      locationUrl: '',
      ownerName: '',
      photos: [],
      smoking: 'notAllowed',
      pets: 'notAllowed',
      furnished: 'yes',
      genderPreference: 'none',
      deposit: 0,
      billsIncluded: false,
    });

    toast({
      title: t('saveListing'),
      description: t('listingSaved'),
    });
  };

  const handleViewDetails = (listing: RoomListing) => {
    setSelectedListing(listing);
    setShowDetailsModal(true);
  };

  const handleShowLocation = () => {
    if (selectedListing?.locationUrl) {
      setShowDetailsModal(false);
      setShowMapModal(true);
    }
  };

  const filteredListings = listings.filter(listing =>
    searchQuery === '' ||
    listing.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    listing.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
    listing.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50/30 via-blue-50/20 to-teal-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      <div className="relative overflow-hidden bg-gradient-to-r from-cyan-500 via-teal-500 to-blue-500 py-16 md:py-24">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container relative mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-white drop-shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-700">
            {t('roommates')}
          </h1>
          <p className="text-lg md:text-xl text-white/95 max-w-2xl mx-auto mb-10 drop-shadow-lg animate-in fade-in slide-in-from-bottom-4 duration-700 delay-150">
            {t('roommatesDesc')}
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 -mt-8">
        <Tabs defaultValue="find" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8 bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm shadow-2xl h-14 rounded-2xl" data-testid="tabs-roommates">
            <TabsTrigger 
              value="find" 
              data-testid="tab-find-roommates"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500 data-[state=active]:to-teal-500 data-[state=active]:text-white font-semibold rounded-xl transition-all duration-300 data-[state=active]:shadow-lg"
            >
              {t('findMatches')}
            </TabsTrigger>
            <TabsTrigger 
              value="listings" 
              data-testid="tab-room-listings"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500 data-[state=active]:to-teal-500 data-[state=active]:text-white font-semibold rounded-xl transition-all duration-300 data-[state=active]:shadow-lg"
            >
              {t('shareMyHome')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="find" className="mt-0 animate-in fade-in duration-500">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 py-6">
              <div className="lg:col-span-1">
                <Card className="shadow-2xl border-2 border-cyan-100/50 dark:border-cyan-900/30 hover:shadow-cyan-500/10 transition-shadow duration-300">
                  <CardHeader className="bg-gradient-to-br from-cyan-50 via-teal-50 to-blue-50 dark:from-cyan-950/30 dark:via-teal-950/30 dark:to-blue-950/30 border-b border-cyan-100/50">
                    <CardTitle className="text-xl font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
                      {t('profile')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6 pt-6">
                    <div className="space-y-2">
                      <Label htmlFor="city" className="font-medium">{t('city')}</Label>
                      <Input
                        id="city"
                        value={profile.city}
                        onChange={(e) => setProfile({ ...profile, city: e.target.value })}
                        placeholder="Milan, Rome, Bologna..."
                        data-testid="input-city"
                        className="border-cyan-200 focus:border-cyan-500 focus:ring-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="university" className="font-medium">{t('university')}</Label>
                      <Input
                        id="university"
                        value={profile.university}
                        onChange={(e) => setProfile({ ...profile, university: e.target.value })}
                        placeholder="University name"
                        data-testid="input-university"
                        className="border-cyan-200 focus:border-cyan-500 focus:ring-cyan-500"
                      />
                    </div>

                    <div className="space-y-4">
                      <Label className="font-medium">{t('budget')}</Label>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="budgetMin" className="text-sm text-muted-foreground">{t('budgetMin')}</Label>
                          <Input
                            id="budgetMin"
                            type="number"
                            value={profile.budgetMin}
                            onChange={(e) => setProfile({ ...profile, budgetMin: Number(e.target.value) })}
                            data-testid="input-budget-min"
                            className="border-cyan-200 focus:border-cyan-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="budgetMax" className="text-sm text-muted-foreground">{t('budgetMax')}</Label>
                          <Input
                            id="budgetMax"
                            type="number"
                            value={profile.budgetMax}
                            onChange={(e) => setProfile({ ...profile, budgetMax: Number(e.target.value) })}
                            data-testid="input-budget-max"
                            className="border-cyan-200 focus:border-cyan-500"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-cyan-50/50 to-teal-50/50 dark:from-cyan-950/20 dark:to-teal-950/20 rounded-lg">
                      <Label htmlFor="pets" className="font-medium">{t('pets')}</Label>
                      <Switch
                        id="pets"
                        checked={profile.pets}
                        onCheckedChange={(checked) => setProfile({ ...profile, pets: checked })}
                        data-testid="switch-pets"
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-cyan-50/50 to-teal-50/50 dark:from-cyan-950/20 dark:to-teal-950/20 rounded-lg">
                      <Label htmlFor="smoker" className="font-medium">{t('smoker')}</Label>
                      <Switch
                        id="smoker"
                        checked={profile.smoker}
                        onCheckedChange={(checked) => setProfile({ ...profile, smoker: checked })}
                        data-testid="switch-smoker"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label className="font-medium">{t('cleanliness')}</Label>
                        <span className="text-sm font-semibold text-cyan-600 dark:text-cyan-400">{profile.cleanliness}/5</span>
                      </div>
                      <Slider
                        value={[profile.cleanliness || 3]}
                        onValueChange={([value]) => setProfile({ ...profile, cleanliness: value })}
                        min={1}
                        max={5}
                        step={1}
                        data-testid="slider-cleanliness"
                        className="[&_[role=slider]]:bg-gradient-to-r [&_[role=slider]]:from-cyan-500 [&_[role=slider]]:to-teal-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label className="font-medium">{t('noiseTolerance')}</Label>
                        <span className="text-sm font-semibold text-cyan-600 dark:text-cyan-400">{profile.noiseTolerance}/5</span>
                      </div>
                      <Slider
                        value={[profile.noiseTolerance || 3]}
                        onValueChange={([value]) => setProfile({ ...profile, noiseTolerance: value })}
                        min={1}
                        max={5}
                        step={1}
                        data-testid="slider-noise"
                        className="[&_[role=slider]]:bg-gradient-to-r [&_[role=slider]]:from-cyan-500 [&_[role=slider]]:to-teal-500"
                      />
                    </div>

                    <div className="space-y-2 pt-4">
                      <Button 
                        className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105" 
                        onClick={handleSaveProfile} 
                        data-testid="button-save-profile"
                      >
                        {t('saveProfile')}
                      </Button>
                      <Button 
                        variant="secondary" 
                        className="w-full hover:bg-cyan-50 dark:hover:bg-cyan-950/30 transition-all duration-300" 
                        onClick={handlePreviewDemo} 
                        data-testid="button-preview-demo"
                      >
                        {t('previewProfiles')}
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full border-2 border-cyan-500 text-cyan-600 hover:bg-cyan-50 dark:hover:bg-cyan-950/30 transition-all duration-300" 
                        onClick={handleFindMatches} 
                        data-testid="button-find-matches"
                      >
                        {t('findMatches')}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-2">
                <h2 className="text-3xl font-bold mb-6 bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
                  {showDemo ? t('previewProfiles') : matches.length > 0 ? t('matches') : t('noMatchesYet')}
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {(showDemo ? demoProfiles : matches).map((p) => (
                    <div key={p.id} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                      <RoommateCard profile={p} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="listings" className="mt-0 animate-in fade-in duration-500">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 py-6">
              <div className="lg:col-span-1">
                <Card className="shadow-2xl border-2 border-cyan-100/50 dark:border-cyan-900/30">
                  <CardHeader className="bg-gradient-to-br from-cyan-50 via-teal-50 to-blue-50 dark:from-cyan-950/30 dark:via-teal-950/30 dark:to-blue-950/30 border-b border-cyan-100/50">
                    <CardTitle className="text-xl font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
                      {t('shareMyHome')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 pt-6">
                    <div className="space-y-2">
                      <Label htmlFor="listing-title" className="font-medium">{t('bureaucracy')}</Label>
                      <Input
                        id="listing-title"
                        value={newListing.title}
                        onChange={(e) => setNewListing({ ...newListing, title: e.target.value })}
                        placeholder="e.g., Cozy Room in City Center"
                        data-testid="input-listing-title"
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="listing-description" className="font-medium">{t('description')}</Label>
                      <Textarea
                        id="listing-description"
                        value={newListing.description}
                        onChange={(e) => setNewListing({ ...newListing, description: e.target.value })}
                        placeholder={t('descriptionPlaceholder')}
                        rows={3}
                        data-testid="textarea-listing-description"
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="listing-city" className="font-medium">{t('city')}</Label>
                      <Input
                        id="listing-city"
                        value={newListing.city}
                        onChange={(e) => setNewListing({ ...newListing, city: e.target.value })}
                        placeholder="Milan, Rome, Bologna..."
                        data-testid="input-listing-city"
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="listing-rent" className="font-medium">{t('rentPrice')}</Label>
                        <Input
                          id="listing-rent"
                          type="number"
                          value={newListing.rentPrice || ''}
                          onChange={(e) => setNewListing({ ...newListing, rentPrice: Number(e.target.value) })}
                          placeholder="450"
                          data-testid="input-listing-rent"
                          className="border-cyan-200 focus:border-cyan-500"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="listing-deposit" className="font-medium">{t('deposit')}</Label>
                        <Input
                          id="listing-deposit"
                          type="number"
                          value={newListing.deposit || ''}
                          onChange={(e) => setNewListing({ ...newListing, deposit: Number(e.target.value) })}
                          placeholder="450"
                          data-testid="input-listing-deposit"
                          className="border-cyan-200 focus:border-cyan-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="listing-smoking" className="font-medium">{t('smoking')}</Label>
                        <Select value={newListing.smoking} onValueChange={(v: 'allowed' | 'notAllowed') => setNewListing({ ...newListing, smoking: v })}>
                          <SelectTrigger id="listing-smoking" data-testid="select-smoking">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="allowed">{t('smokingAllowed')}</SelectItem>
                            <SelectItem value="notAllowed">{t('noSmoking')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="listing-pets" className="font-medium">{t('pets')}</Label>
                        <Select value={newListing.pets} onValueChange={(v: 'allowed' | 'notAllowed') => setNewListing({ ...newListing, pets: v })}>
                          <SelectTrigger id="listing-pets" data-testid="select-pets">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="allowed">{t('petFriendly')}</SelectItem>
                            <SelectItem value="notAllowed">{t('noPets')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="listing-furnished" className="font-medium">{t('furnished')}</Label>
                        <Select value={newListing.furnished} onValueChange={(v: 'yes' | 'no') => setNewListing({ ...newListing, furnished: v })}>
                          <SelectTrigger id="listing-furnished" data-testid="select-furnished">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="yes">{t('furnished')}</SelectItem>
                            <SelectItem value="no">{t('unfurnished')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="listing-gender" className="font-medium">{t('genderPreference')}</Label>
                        <Select value={newListing.genderPreference} onValueChange={(v: 'female' | 'male' | 'none') => setNewListing({ ...newListing, genderPreference: v })}>
                          <SelectTrigger id="listing-gender" data-testid="select-gender">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">{t('noPreference')}</SelectItem>
                            <SelectItem value="female">{t('femaleOnly')}</SelectItem>
                            <SelectItem value="male">{t('maleOnly')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-cyan-50/50 to-teal-50/50 dark:from-cyan-950/20 dark:to-teal-950/20 rounded-lg">
                      <Label htmlFor="listing-bills" className="font-medium">{t('billsIncluded')}</Label>
                      <Switch
                        id="listing-bills"
                        checked={newListing.billsIncluded}
                        onCheckedChange={(checked) => setNewListing({ ...newListing, billsIncluded: checked })}
                        data-testid="switch-bills"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="listing-location" className="font-medium">{t('locationLink')}</Label>
                      <Input
                        id="listing-location"
                        value={newListing.locationUrl}
                        onChange={(e) => setNewListing({ ...newListing, locationUrl: e.target.value })}
                        placeholder={t('locationLinkPlaceholder')}
                        data-testid="input-listing-location"
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="listing-owner" className="font-medium">Owner Name</Label>
                      <Input
                        id="listing-owner"
                        value={newListing.ownerName}
                        onChange={(e) => setNewListing({ ...newListing, ownerName: e.target.value })}
                        placeholder="Your name"
                        data-testid="input-listing-owner"
                        className="border-cyan-200 focus:border-cyan-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="listing-photos" className="font-medium">{t('uploadPhotos')}</Label>
                      <label htmlFor="listing-photos">
                        <Button
                          variant="outline"
                          className="w-full gap-2 border-2 border-dashed border-cyan-300 hover:border-cyan-500 hover:bg-cyan-50 dark:hover:bg-cyan-950/30"
                          asChild
                          data-testid="button-upload-photos"
                        >
                          <span>
                            <Upload className="h-4 w-4" />
                            {t('uploadPhotos')}
                          </span>
                        </Button>
                      </label>
                      <input
                        id="listing-photos"
                        type="file"
                        className="hidden"
                        onChange={handlePhotoUpload}
                        accept="image/*"
                        multiple
                      />
                      {newListing.photos && newListing.photos.length > 0 && (
                        <div className="grid grid-cols-4 gap-2 mt-2">
                          {newListing.photos.map((photo, idx) => (
                            <div key={idx} className="relative aspect-square group">
                              <img src={photo} alt={`Photo ${idx + 1}`} className="w-full h-full object-cover rounded-md ring-2 ring-cyan-200" />
                              <Button
                                variant="destructive"
                                size="icon"
                                className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => {
                                  const photos = [...(newListing.photos || [])];
                                  photos.splice(idx, 1);
                                  setNewListing({ ...newListing, photos });
                                }}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <Button 
                      className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105" 
                      onClick={handleSaveListing} 
                      data-testid="button-save-listing"
                    >
                      {t('saveListing')}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-2">
                <div className="mb-6 space-y-4">
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
                    {t('roomListings')}
                  </h2>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-cyan-500" />
                    <Input
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search by title, city, or description..."
                      className="pl-10 border-2 border-cyan-200 focus:border-cyan-500 focus:ring-cyan-500 h-12 text-base shadow-lg"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredListings.map((listing) => (
                    <div key={listing.id} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                      <RoomListingCard 
                        listing={listing}
                        onViewDetails={handleViewDetails}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showDetailsModal} onOpenChange={setShowDetailsModal}>
        <DialogContent className="max-w-2xl" data-testid="dialog-listing-details">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedListing?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">{t('description')}</h3>
              <p className="text-muted-foreground">{selectedListing?.description}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold mb-1">{t('city')}</h3>
                <p className="text-muted-foreground">{selectedListing?.city}</p>
              </div>
              <div>
                <h3 className="font-semibold mb-1">{t('rentPrice')}</h3>
                <p className="text-muted-foreground">€{selectedListing?.rentPrice}/month</p>
              </div>
            </div>
            {selectedListing?.locationUrl && (
              <Button 
                onClick={handleShowLocation} 
                className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600"
                data-testid="button-show-location"
              >
                {t('showLocation')}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {selectedListing?.locationUrl && (
        <MapModal
          open={showMapModal}
          onOpenChange={setShowMapModal}
          locationUrl={selectedListing.locationUrl}
          title={selectedListing.title}
        />
      )}
    </div>
  );
}
