import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarIcon, Trash2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export interface Reminder {
  id: string;
  title: string;
  dueDate: string;
  category: string;
}

interface ReminderItemProps {
  reminder: Reminder;
  onDelete?: (id: string) => void;
}

export default function ReminderItem({ reminder, onDelete }: ReminderItemProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);

  const dueDate = new Date(reminder.dueDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(dueDate);
  due.setHours(0, 0, 0, 0);
  
  const daysUntilDue = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  
  let urgencyClass = 'border-l-success';
  if (daysUntilDue < 0) urgencyClass = 'border-l-destructive';
  else if (daysUntilDue <= 3) urgencyClass = 'border-l-warning';

  return (
    <Card className={`border-l-4 ${urgencyClass} hover-elevate`} data-testid={`reminder-${reminder.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-base truncate">{reminder.title}</h3>
              <Badge variant="secondary" className="text-xs">
                {reminder.category.toUpperCase()}
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <CalendarIcon className="h-4 w-4" />
              <span>{dueDate.toLocaleDateString(language)}</span>
              {daysUntilDue >= 0 && (
                <span className="text-xs">({daysUntilDue} {daysUntilDue === 1 ? t('day') : t('days')})</span>
              )}
              {daysUntilDue < 0 && (
                <Badge variant="destructive" className="text-xs">{t('overdue')}</Badge>
              )}
            </div>
          </div>
          {onDelete && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(reminder.id)}
              className="shrink-0"
              data-testid={`button-delete-${reminder.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
