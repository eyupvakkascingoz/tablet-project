import { Link, useLocation } from 'wouter';
import { Moon, Sun, FileText, Users, Calendar, MessageSquare, Settings as SettingsIcon, HelpCircle, Briefcase, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/contexts/ThemeContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation, type Language } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const languageFlags: Record<Language, string> = {
  en: '🇬🇧',
  it: '🇮🇹',
  tr: '🇹🇷',
  ar: '🇸🇦',
};

const languageNames: Record<Language, string> = {
  en: 'English',
  it: 'Italiano',
  tr: 'Türkçe',
  ar: 'العربية',
};

export default function Navbar() {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();

  const handleOnlineCAF = () => {
    toast({
      title: t('onlineCaf'),
      description: t('onlineCafComingSoon'),
    });
  };

  const navItems = [
    { path: '/', label: t('home'), icon: Home, type: 'link' },
    { path: '/bureaucracy', label: t('bureaucracy'), icon: FileText, type: 'link' },
    { path: '/roommates', label: t('roommates'), icon: Users, type: 'link' },
    { path: '/community', label: t('communityBoard'), icon: HelpCircle, type: 'link' },
    { path: '/chat', label: t('chat'), icon: MessageSquare, type: 'link' },
    { path: '', label: t('onlineCaf'), icon: Briefcase, type: 'button', onClick: handleOnlineCAF },
    { path: '/calendar', label: t('reminders'), icon: Calendar, type: 'link' },
    { path: '/settings', label: t('settings'), icon: SettingsIcon, type: 'link' },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-cyan-100 bg-gradient-to-r from-cyan-50 via-white to-cyan-50 backdrop-blur-lg supports-[backdrop-filter]:bg-white/80 shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300 hover:scale-105 active:scale-95" data-testid="link-home">
          <div className="relative">
            <FileText className="h-6 w-6 text-cyan-600" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-cyan-600 via-primary to-cyan-500 bg-clip-text text-transparent">{t('appName')}</span>
        </Link>

        <div className="hidden md:flex items-center gap-2">
          {navItems.map(({ path, label, icon: Icon, type, onClick }) => (
            type === 'button' ? (
              <Button
                key={label}
                variant="outline"
                size="sm"
                className="gap-2 border-2 border-cyan-200 hover:border-cyan-400 hover:bg-cyan-50 transition-all duration-300 hover:scale-105 active:scale-95"
                onClick={onClick}
                data-testid="button-online-caf"
              >
                <Icon className="h-4 w-4" />
                {label}
              </Button>
            ) : (
              <Link key={path} href={path} data-testid={`link-${path.slice(1)}`}>
                <Button
                  variant={location === path ? 'default' : 'outline'}
                  size="sm"
                  className={`gap-2 border-2 transition-all duration-300 hover:scale-105 active:scale-95 ${
                    location === path 
                      ? 'bg-gradient-to-r from-cyan-500 to-primary border-cyan-400' 
                      : 'border-cyan-200 hover:border-cyan-400 hover:bg-cyan-50'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {label}
                </Button>
              </Link>
            )
          ))}
        </div>

        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-2" data-testid="button-language">
                <span>{languageFlags[language]}</span>
                <span className="hidden sm:inline">{languageNames[language]}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {(Object.keys(languageFlags) as Language[]).map((lang) => (
                <DropdownMenuItem
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  className="gap-2"
                  data-testid={`button-language-${lang}`}
                >
                  <span>{languageFlags[lang]}</span>
                  <span>{languageNames[lang]}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
          >
            {theme === 'light' ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5" />
            )}
          </Button>
        </div>
      </div>

      <div className="md:hidden border-t border-cyan-100 bg-gradient-to-r from-cyan-50 via-white to-cyan-50">
        <div className="container mx-auto px-4 py-2 flex gap-1 overflow-x-auto">
          {navItems.map(({ path, label, icon: Icon, type, onClick }) => (
            type === 'button' ? (
              <Button
                key={label}
                variant="outline"
                size="sm"
                className="gap-2 whitespace-nowrap border-2 border-cyan-200 hover:border-cyan-400 hover:bg-cyan-50 transition-all duration-300"
                onClick={onClick}
                data-testid="button-mobile-online-caf"
              >
                <Icon className="h-4 w-4" />
                {label}
              </Button>
            ) : (
              <Link key={path} href={path} data-testid={`link-mobile-${path.slice(1)}`}>
                <Button
                  variant={location === path ? 'default' : 'outline'}
                  size="sm"
                  className={`gap-2 whitespace-nowrap border-2 transition-all duration-300 ${
                    location === path 
                      ? 'bg-gradient-to-r from-cyan-500 to-primary border-cyan-400' 
                      : 'border-cyan-200 hover:border-cyan-400 hover:bg-cyan-50'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {label}
                </Button>
              </Link>
            )
          ))}
        </div>
      </div>
    </nav>
  );
}
