import { LanguageProvider } from '@/contexts/LanguageContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import ReminderItem from '../ReminderItem';

const mockReminders = [
  {
    id: '1',
    title: 'ISEE Università',
    dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    category: 'isee',
  },
  {
    id: '2',
    title: 'Permesso di Soggiorno',
    dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    category: 'permesso',
  },
  {
    id: '3',
    title: 'SPID Activation',
    dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    category: 'spid',
  },
];

export default function ReminderItemExample() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <div className="p-8 space-y-4">
          {mockReminders.map(reminder => (
            <ReminderItem 
              key={reminder.id} 
              reminder={reminder} 
              onDelete={(id) => console.log('Delete reminder:', id)}
            />
          ))}
        </div>
      </LanguageProvider>
    </ThemeProvider>
  );
}
