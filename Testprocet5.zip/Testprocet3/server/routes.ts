import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { askChatbot } from "./chatbot";
import { analyzeDocument } from "./documentAnalysis";

export async function registerRoutes(app: Express): Promise<Server> {
  // Chatbot endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, language } = req.body;
      
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      const chatResponse = await askChatbot(message, language || 'en');
      res.json({ 
        response: chatResponse.text,
        actions: chatResponse.actions 
      });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  // Document analysis endpoint
  app.post("/api/analyze-document", async (req, res) => {
    try {
      const { imageBase64, language } = req.body;
      
      if (!imageBase64) {
        return res.status(400).json({ error: "Image data is required" });
      }

      const result = await analyzeDocument(imageBase64, language || 'it');
      res.json(result);
    } catch (error) {
      console.error("Document analysis error:", error);
      res.status(500).json({ error: "Failed to analyze document" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
