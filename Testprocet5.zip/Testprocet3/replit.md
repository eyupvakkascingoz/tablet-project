# DocuBuddy+ - Student Documentation Assistant

## Overview

DocuBuddy+ is a full-stack web application designed to help international students in Italy manage bureaucratic tasks, find compatible roommates, and track important deadlines. The application is built with a modern React + Express stack using Vite as the build tool and features a multilingual interface supporting Italian, English, Turkish, and Arabic (with RTL support).

The application features an AI-powered chatbot (DocuBot) that helps students with bureaucratic questions in multiple languages. The chatbot uses Google's Gemini AI and appears as a friendly robot assistant in the bottom-right corner of every page.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (October 2025)

### October 16, 2025 - UI/UX Enhancements
- ✅ Implemented turquoise/cyan gradient theme throughout the application (navbar, cards, buttons, chat widget)
- ✅ Added prominent CAF Search button on homepage with gradient styling and smooth animations
- ✅ Implemented chat auto-scroll functionality with scroll position tracking and "new messages" indicator
- ✅ Made ChatWidget fully responsive:
  - Mobile: Full-screen layout (100% width/height) for optimal mobile experience
  - Desktop: Fixed 384px panel with rounded corners positioned bottom-right
  - Smooth transitions and hover effects with Tailwind CSS
- ✅ Enhanced button animations with scale effects on hover/active states
- ✅ Cleaned up debug console logs for production readiness
- ✅ All improvements architect-reviewed and verified

### October 18, 2025 - Fresh Replit Environment Setup (GitHub Import)
- ✅ Successfully extracted and organized GitHub project from zip archive
- ✅ Installed Node.js 20 module and all npm dependencies (501 packages)
- ✅ Configured Vite dev server with Replit proxy support (allowedHosts: true for iframe compatibility)
- ✅ Added cache-control headers (no-cache, no-store) to prevent browser caching issues
- ✅ Set up workflow "Server" to run `npm run dev` on port 5000
- ✅ Verified application runs successfully - all features working perfectly
- ✅ Configured deployment for Autoscale with build and production start commands
- ✅ PostgreSQL database already configured (DATABASE_URL available)
- ✅ **GEMINI_API_KEY configured** - Document analysis and AI chatbot features now fully operational
- ✅ Document Analysis feature tested and working:
  - AI-powered document type detection (ISEE, Permesso, Codice Fiscale, etc.)
  - Confidence scoring and keyword extraction
  - Support for JPG, PNG, and PDF files up to 10MB
  - Multilingual analysis support (Italian and Turkish)

### Previous Changes
- ✅ Added DocuBot - AI chatbot with robot design in bottom-right corner
- ✅ Robot button is fixed position - stays visible when scrolling
- ✅ Server running on port 5000 (frontend + backend)

## System Architecture

### Frontend Architecture

**Framework Stack:**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server for fast HMR and optimized builds
- **Wouter** for client-side routing (lightweight alternative to React Router)
- **TanStack Query** for state management and data fetching patterns (though actual data comes from localStorage)

**UI Framework:**
- **shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design tokens
- **Material Design 3** principles adapted for web (clarity-first approach for bureaucratic tasks)

**Design System:**
- Custom color palette with light/dark mode support defined in CSS variables
- Trustworthy blue primary color (220 70% 50%) for institutional feel
- Success/error states for document validation feedback
- RTL layout support for Arabic language
- Inter font family for excellent multilingual support

### Data Architecture

**Storage Strategy:**
- **localStorage** as the sole persistence mechanism
- No database or backend services
- Data stored as JSON strings in browser storage
- Key storage areas:
  - `reminders` - Array of reminder objects with title, dueDate, createdAt, and category
  - `language` - User's selected language preference
  - `theme` - Light/dark mode preference
  - `roommateProfile` - User's roommate matching preferences
  - Bureaucracy flow states (ISEE, Permesso, SPID checklists and upload statuses)

**State Management:**
- React Context API for global state (Theme, Language)
- Component-level state with hooks for ephemeral UI state
- localStorage synchronization via useEffect hooks

### Application Structure

**Directory Organization:**
```
client/src/
├── components/          # Reusable UI components
│   ├── ui/             # shadcn/ui base components
│   └── [feature].tsx   # Feature-specific components
├── contexts/           # React Context providers
├── hooks/              # Custom React hooks
├── lib/                # Utility functions and helpers
├── pages/              # Page components for routing
└── App.tsx             # Root application component
```

**Key Features:**

1. **Bureaucracy Manager** - Three main workflows (ISEE, Permesso di Soggiorno, SPID) with:
   - 5-6 step checklists per flow
   - File upload simulation with status detection (expired files marked red, valid files green)
   - CAF appointment booking integration with automatic reminder creation
   - Multi-university support (Polimi, Sapienza) with region-specific CAF providers

2. **Roommate Finder** - Lifestyle-based matching system:
   - Profile creation form with city, university, budget, lifestyle preferences
   - Client-side matching algorithm calculating compatibility percentage
   - Scoring based on: same city (+20), budget overlap (+15), pet/smoker compatibility (+10 each), cleanliness/noise tolerance similarity (up to +20)
   - Demo profile previews for testing

3. **Calendar/Reminders** - Simple deadline tracking:
   - Displays reminders sorted by due date
   - Visual urgency indicators (red for overdue, yellow for <3 days, green for safe)
   - Integration with bureaucracy flows for automatic reminder creation
   - Delete functionality to remove completed tasks

4. **Internationalization** - Full i18n support:
   - Four languages: IT, EN, TR, AR
   - RTL layout automatic switching for Arabic
   - Language selector in navigation
   - Translation keys managed in `lib/i18n.ts`

### Routing Architecture

**Client-Side Routes:**
- `/` - Landing page with feature overview
- `/bureaucracy` - Bureaucracy task management
- `/roommates` - Roommate profile and matching
- `/calendar` - Reminder list view
- `/settings` - Language preferences
- Fallback 404 page for unmatched routes

### Build and Development

**Development Setup:**
- Vite dev server with HMR on port 5173
- Express backend proxy for development (serves Vite middleware)
- Replit-specific plugins for runtime error overlay and dev tools

**Production Build:**
- Client bundle outputs to `dist/public`
- Server bundle outputs to `dist` (though server is minimal, primarily for static file serving)
- esbuild for server bundling (ESM format)

**Scripts:**
- `dev` - Runs development server with tsx
- `build` - Builds both client (Vite) and server (esbuild)
- `start` - Production server (Node.js)

## External Dependencies

### UI Component Libraries
- **@radix-ui/** - Comprehensive suite of unstyled, accessible UI primitives (accordion, dialog, dropdown, tooltip, etc.)
- **shadcn/ui** - Pre-built component patterns using Radix primitives
- **lucide-react** - Icon library for UI elements
- **cmdk** - Command palette component
- **embla-carousel-react** - Carousel/slider functionality

### Form Management
- **react-hook-form** - Form state management and validation
- **@hookform/resolvers** - Validation schema resolvers
- **zod** - TypeScript-first schema validation

### Styling
- **tailwindcss** - Utility-first CSS framework
- **tailwind-merge** - Utility for merging Tailwind classes
- **class-variance-authority** - Variant-based component styling
- **autoprefixer** - CSS vendor prefixing

### Database (Configured but Not Used)
- **drizzle-orm** - TypeScript ORM (configured for PostgreSQL but no actual database connection in current build)
- **drizzle-kit** - Schema migrations tool
- **@neondatabase/serverless** - Neon PostgreSQL driver
- **drizzle-zod** - Zod schema generation from Drizzle schemas

Note: Database infrastructure is set up but the application currently operates entirely client-side with localStorage. The database schema exists for potential future backend integration.

### Date Handling
- **date-fns** - Date manipulation and formatting library

### Development Tools
- **Vite** - Build tool and dev server
- **TypeScript** - Type-safe JavaScript
- **@vitejs/plugin-react** - React support for Vite
- **tsx** - TypeScript execution for Node.js
- **esbuild** - Fast JavaScript bundler

### Replit Integration
- **@replit/vite-plugin-runtime-error-modal** - Runtime error overlay
- **@replit/vite-plugin-cartographer** - Project navigation
- **@replit/vite-plugin-dev-banner** - Development mode indicator

### Session Management (Server-Side, Currently Unused)
- **express-session** - Session middleware
- **connect-pg-simple** - PostgreSQL session store

The application is designed to be fully functional without backend services, making all external dependencies purely client-side except for the minimal Express server used for static file serving in production.