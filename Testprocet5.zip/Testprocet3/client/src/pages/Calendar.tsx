import { useState, useEffect } from 'react';
import ReminderItem, { type Reminder } from '@/components/ReminderItem';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { Calendar as CalendarIcon } from 'lucide-react';

export default function Calendar() {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const [reminders, setReminders] = useState<Reminder[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem('reminders');
    if (stored) {
      setReminders(JSON.parse(stored));
    }
  }, []);

  const handleDelete = (id: string) => {
    const updated = reminders.filter(r => r.id !== id);
    setReminders(updated);
    localStorage.setItem('reminders', JSON.stringify(updated));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">{t('calendar')}</h1>
        <p className="text-muted-foreground">{t('calendarDesc')}</p>
      </div>

      {reminders.length === 0 ? (
        <div className="text-center py-12">
          <CalendarIcon className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-semibold mb-2 text-foreground">{t('noRemindersYet')}</h3>
          <p className="text-muted-foreground">{t('addRemindersFrom')}</p>
        </div>
      ) : (
        <div className="max-w-3xl mx-auto space-y-4">
          {reminders
            .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
            .map((reminder) => (
              <ReminderItem key={reminder.id} reminder={reminder} onDelete={handleDelete} />
            ))}
        </div>
      )}
    </div>
  );
}
