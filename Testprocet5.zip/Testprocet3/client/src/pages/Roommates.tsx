import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Upload, X } from 'lucide-react';
import RoommateCard, { type RoommateProfile } from '@/components/RoommateCard';
import RoomListingCard, { type RoomListing } from '@/components/RoomListingCard';
import MapModal from '@/components/MapModal';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

//todo: remove mock functionality
const demoProfiles: RoommateProfile[] = [
  {
    id: '1',
    name: 'Maria Rossi',
    city: 'Milan',
    university: 'Politecnico di Milano',
    budgetMin: 400,
    budgetMax: 600,
    pets: false,
    smoker: false,
    cleanliness: 5,
    noiseTolerance: 3,
  },
  {
    id: '2',
    name: 'Ahmed Hassan',
    city: 'Rome',
    university: 'Sapienza University',
    budgetMin: 350,
    budgetMax: 500,
    pets: true,
    smoker: false,
    cleanliness: 4,
    noiseTolerance: 4,
  },
  {
    id: '3',
    name: 'Sophie Martin',
    city: 'Milan',
    university: 'Bocconi University',
    budgetMin: 500,
    budgetMax: 700,
    pets: false,
    smoker: false,
    cleanliness: 4,
    noiseTolerance: 2,
  },
];

const demoListings: RoomListing[] = [
  {
    id: '1',
    title: 'Cozy Room in City Center',
    description: 'Bright room in shared apartment, close to metro station. Fully furnished with wifi.',
    city: 'Milan',
    rentPrice: 450,
    locationUrl: 'https://www.google.com/maps/place/Milan,+Metropolitan+City+of+Milan,+Italy/@45.4668,9.1905,11z',
    ownerName: 'Giulia Bianchi',
    smoking: 'notAllowed',
    pets: 'allowed',
    furnished: 'yes',
    genderPreference: 'none',
    deposit: 900,
    billsIncluded: true,
  },
  {
    id: '2',
    title: 'Student Room Near University',
    description: 'Perfect for students! Walking distance to Sapienza University. Shared kitchen and living room.',
    city: 'Rome',
    rentPrice: 380,
    locationUrl: 'https://www.google.com/maps/place/Rome,+Metropolitan+City+of+Rome,+Italy/@41.9028,12.4964,11z',
    ownerName: 'Marco Russo',
    smoking: 'notAllowed',
    pets: 'notAllowed',
    furnished: 'yes',
    genderPreference: 'female',
    deposit: 380,
    billsIncluded: false,
  },
];

export default function Roommates() {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();

  const [profile, setProfile] = useState<Partial<RoommateProfile>>({
    city: '',
    university: '',
    budgetMin: 300,
    budgetMax: 600,
    pets: false,
    smoker: false,
    cleanliness: 3,
    noiseTolerance: 3,
  });

  const [matches, setMatches] = useState<RoommateProfile[]>([]);
  const [showDemo, setShowDemo] = useState(false);

  // Room Listings State
  const [listings, setListings] = useState<RoomListing[]>(() => {
    const saved = localStorage.getItem('roomListings');
    return saved ? JSON.parse(saved) : demoListings;
  });
  
  const [newListing, setNewListing] = useState<Partial<RoomListing>>({
    title: '',
    description: '',
    city: '',
    rentPrice: 0,
    locationUrl: '',
    ownerName: '',
    photos: [],
    smoking: 'notAllowed',
    pets: 'notAllowed',
    furnished: 'yes',
    genderPreference: 'none',
    deposit: 0,
    billsIncluded: false,
  });

  const [selectedListing, setSelectedListing] = useState<RoomListing | null>(null);
  const [showMapModal, setShowMapModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const calculateMatch = (other: RoommateProfile): number => {
    let score = 0;
    
    if (profile.city === other.city) score += 20;
    
    const budgetOverlap = Math.min(profile.budgetMax || 0, other.budgetMax) - 
                          Math.max(profile.budgetMin || 0, other.budgetMin);
    if (budgetOverlap > 0) score += 15;
    
    if (profile.pets === other.pets) score += 10;
    if (profile.smoker === other.smoker) score += 10;
    
    const cleanDiff = Math.abs((profile.cleanliness || 3) - other.cleanliness);
    score += Math.max(0, 20 - cleanDiff * 4);
    
    const noiseDiff = Math.abs((profile.noiseTolerance || 3) - other.noiseTolerance);
    score += Math.max(0, 20 - noiseDiff * 4);
    
    return Math.min(100, Math.round(score));
  };

  const handleSaveProfile = () => {
    localStorage.setItem('roommateProfile', JSON.stringify(profile));
    toast({
      title: t('saveProfile'),
      description: t('profileSavedSuccessfully'),
    });
  };

  const handlePreviewDemo = () => {
    setShowDemo(!showDemo);
  };

  const handleFindMatches = () => {
    if (!profile.city) {
      toast({
        title: 'Profile Incomplete',
        description: 'Please select a city',
        variant: 'destructive',
      });
      return;
    }

    const matchedProfiles = demoProfiles
      .map(p => ({ ...p, matchPercentage: calculateMatch(p) }))
      .sort((a, b) => (b.matchPercentage || 0) - (a.matchPercentage || 0));
    
    setMatches(matchedProfiles);
    setShowDemo(false);
    
    toast({
      title: t('findMatches'),
      description: `${t('foundMatches')} ${matchedProfiles.length} ${t('matches_count')}`,
    });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const currentPhotos = newListing.photos || [];
    const remainingSlots = 8 - currentPhotos.length;
    
    if (remainingSlots <= 0) {
      toast({
        title: t('uploadPhotos'),
        description: 'Maximum 8 photos allowed',
        variant: 'destructive',
      });
      return;
    }

    const fileArray = Array.from(files).slice(0, remainingSlots);
    const photoPromises = fileArray.map(file => {
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
    });

    Promise.all(photoPromises).then(photos => {
      setNewListing({ ...newListing, photos: [...currentPhotos, ...photos] });
    });
  };

  const handleSaveListing = () => {
    if (!newListing.title || !newListing.city || !newListing.rentPrice || !newListing.ownerName) {
      toast({
        title: 'Listing Incomplete',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const listing: RoomListing = {
      id: Date.now().toString(),
      title: newListing.title!,
      description: newListing.description || '',
      city: newListing.city!,
      rentPrice: newListing.rentPrice!,
      locationUrl: newListing.locationUrl,
      ownerName: newListing.ownerName!,
      photos: newListing.photos || [],
      smoking: newListing.smoking || 'notAllowed',
      pets: newListing.pets || 'notAllowed',
      furnished: newListing.furnished || 'yes',
      genderPreference: newListing.genderPreference || 'none',
      deposit: newListing.deposit || 0,
      billsIncluded: newListing.billsIncluded || false,
    };

    const updatedListings = [...listings, listing];
    setListings(updatedListings);
    localStorage.setItem('roomListings', JSON.stringify(updatedListings));

    // Reset form
    setNewListing({
      title: '',
      description: '',
      city: '',
      rentPrice: 0,
      locationUrl: '',
      ownerName: '',
      photos: [],
      smoking: 'notAllowed',
      pets: 'notAllowed',
      furnished: 'yes',
      genderPreference: 'none',
      deposit: 0,
      billsIncluded: false,
    });

    toast({
      title: t('saveListing'),
      description: t('listingSaved'),
    });
  };

  const handleViewDetails = (listing: RoomListing) => {
    setSelectedListing(listing);
    setShowDetailsModal(true);
  };

  const handleShowLocation = () => {
    if (selectedListing?.locationUrl) {
      setShowDetailsModal(false);
      setShowMapModal(true);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">{t('roommates')}</h1>
        <p className="text-muted-foreground">{t('roommatesDesc')}</p>
      </div>

      <Tabs defaultValue="find" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2 mb-6" data-testid="tabs-roommates">
          <TabsTrigger value="find" data-testid="tab-find-roommates">{t('findMatches')}</TabsTrigger>
          <TabsTrigger value="listings" data-testid="tab-room-listings">{t('shareMyHome')}</TabsTrigger>
        </TabsList>

        {/* Find Roommates Tab */}
        <TabsContent value="find">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>{t('profile')}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="city">{t('city')}</Label>
                    <Input
                      id="city"
                      value={profile.city}
                      onChange={(e) => setProfile({ ...profile, city: e.target.value })}
                      placeholder="Milan, Rome, Bologna..."
                      data-testid="input-city"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="university">{t('university')}</Label>
                    <Input
                      id="university"
                      value={profile.university}
                      onChange={(e) => setProfile({ ...profile, university: e.target.value })}
                      placeholder="University name"
                      data-testid="input-university"
                    />
                  </div>

                  <div className="space-y-4">
                    <Label>{t('budget')}</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="budgetMin" className="text-sm text-muted-foreground">{t('budgetMin')}</Label>
                        <Input
                          id="budgetMin"
                          type="number"
                          value={profile.budgetMin}
                          onChange={(e) => setProfile({ ...profile, budgetMin: Number(e.target.value) })}
                          data-testid="input-budget-min"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="budgetMax" className="text-sm text-muted-foreground">{t('budgetMax')}</Label>
                        <Input
                          id="budgetMax"
                          type="number"
                          value={profile.budgetMax}
                          onChange={(e) => setProfile({ ...profile, budgetMax: Number(e.target.value) })}
                          data-testid="input-budget-max"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="pets">{t('pets')}</Label>
                    <Switch
                      id="pets"
                      checked={profile.pets}
                      onCheckedChange={(checked) => setProfile({ ...profile, pets: checked })}
                      data-testid="switch-pets"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="smoker">{t('smoker')}</Label>
                    <Switch
                      id="smoker"
                      checked={profile.smoker}
                      onCheckedChange={(checked) => setProfile({ ...profile, smoker: checked })}
                      data-testid="switch-smoker"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>{t('cleanliness')}</Label>
                      <span className="text-sm text-muted-foreground">{profile.cleanliness}/5</span>
                    </div>
                    <Slider
                      value={[profile.cleanliness || 3]}
                      onValueChange={([value]) => setProfile({ ...profile, cleanliness: value })}
                      min={1}
                      max={5}
                      step={1}
                      data-testid="slider-cleanliness"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>{t('noiseTolerance')}</Label>
                      <span className="text-sm text-muted-foreground">{profile.noiseTolerance}/5</span>
                    </div>
                    <Slider
                      value={[profile.noiseTolerance || 3]}
                      onValueChange={([value]) => setProfile({ ...profile, noiseTolerance: value })}
                      min={1}
                      max={5}
                      step={1}
                      data-testid="slider-noise"
                    />
                  </div>

                  <div className="space-y-2">
                    <Button className="w-full" onClick={handleSaveProfile} data-testid="button-save-profile">
                      {t('saveProfile')}
                    </Button>
                    <Button variant="secondary" className="w-full" onClick={handlePreviewDemo} data-testid="button-preview-demo">
                      {t('previewProfiles')}
                    </Button>
                    <Button variant="outline" className="w-full" onClick={handleFindMatches} data-testid="button-find-matches">
                      {t('findMatches')}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-2">
              <h2 className="text-2xl font-semibold mb-4 text-foreground">
                {showDemo ? t('previewProfiles') : matches.length > 0 ? t('matches') : t('noMatchesYet')}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(showDemo ? demoProfiles : matches).map((p) => (
                  <RoommateCard key={p.id} profile={p} />
                ))}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Room Listings Tab */}
        <TabsContent value="listings">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>{t('shareMyHome')}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="listing-title">{t('bureaucracy')}</Label>
                    <Input
                      id="listing-title"
                      value={newListing.title}
                      onChange={(e) => setNewListing({ ...newListing, title: e.target.value })}
                      placeholder="e.g., Cozy Room in City Center"
                      data-testid="input-listing-title"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-description">{t('description')}</Label>
                    <Textarea
                      id="listing-description"
                      value={newListing.description}
                      onChange={(e) => setNewListing({ ...newListing, description: e.target.value })}
                      placeholder={t('descriptionPlaceholder')}
                      rows={3}
                      data-testid="textarea-listing-description"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-city">{t('city')}</Label>
                    <Input
                      id="listing-city"
                      value={newListing.city}
                      onChange={(e) => setNewListing({ ...newListing, city: e.target.value })}
                      placeholder="Milan, Rome, Bologna..."
                      data-testid="input-listing-city"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-rent">{t('rentPrice')}</Label>
                    <Input
                      id="listing-rent"
                      type="number"
                      value={newListing.rentPrice || ''}
                      onChange={(e) => setNewListing({ ...newListing, rentPrice: Number(e.target.value) })}
                      placeholder="450"
                      data-testid="input-listing-rent"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-deposit">{t('deposit')}</Label>
                    <Input
                      id="listing-deposit"
                      type="number"
                      value={newListing.deposit || ''}
                      onChange={(e) => setNewListing({ ...newListing, deposit: Number(e.target.value) })}
                      placeholder="450"
                      data-testid="input-listing-deposit"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-smoking">{t('smoking')}</Label>
                    <Select value={newListing.smoking} onValueChange={(v: 'allowed' | 'notAllowed') => setNewListing({ ...newListing, smoking: v })}>
                      <SelectTrigger id="listing-smoking" data-testid="select-smoking">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="allowed">{t('smokingAllowed')}</SelectItem>
                        <SelectItem value="notAllowed">{t('noSmoking')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-pets">{t('pets')}</Label>
                    <Select value={newListing.pets} onValueChange={(v: 'allowed' | 'notAllowed') => setNewListing({ ...newListing, pets: v })}>
                      <SelectTrigger id="listing-pets" data-testid="select-pets">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="allowed">{t('petFriendly')}</SelectItem>
                        <SelectItem value="notAllowed">{t('noPets')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-furnished">{t('furnished')}</Label>
                    <Select value={newListing.furnished} onValueChange={(v: 'yes' | 'no') => setNewListing({ ...newListing, furnished: v })}>
                      <SelectTrigger id="listing-furnished" data-testid="select-furnished">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="yes">{t('furnished')}</SelectItem>
                        <SelectItem value="no">{t('unfurnished')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-gender">{t('genderPreference')}</Label>
                    <Select value={newListing.genderPreference} onValueChange={(v: 'female' | 'male' | 'none') => setNewListing({ ...newListing, genderPreference: v })}>
                      <SelectTrigger id="listing-gender" data-testid="select-gender">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">{t('noPreference')}</SelectItem>
                        <SelectItem value="female">{t('femaleOnly')}</SelectItem>
                        <SelectItem value="male">{t('maleOnly')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="listing-bills">{t('billsIncluded')}</Label>
                    <Switch
                      id="listing-bills"
                      checked={newListing.billsIncluded}
                      onCheckedChange={(checked) => setNewListing({ ...newListing, billsIncluded: checked })}
                      data-testid="switch-bills"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-location">{t('locationLink')}</Label>
                    <Input
                      id="listing-location"
                      value={newListing.locationUrl}
                      onChange={(e) => setNewListing({ ...newListing, locationUrl: e.target.value })}
                      placeholder={t('locationLinkPlaceholder')}
                      data-testid="input-listing-location"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-owner">Owner Name</Label>
                    <Input
                      id="listing-owner"
                      value={newListing.ownerName}
                      onChange={(e) => setNewListing({ ...newListing, ownerName: e.target.value })}
                      placeholder="Your name"
                      data-testid="input-listing-owner"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="listing-photos">{t('uploadPhotos')}</Label>
                    <label htmlFor="listing-photos">
                      <Button
                        variant="outline"
                        className="w-full gap-2"
                        asChild
                        data-testid="button-upload-photos"
                      >
                        <span>
                          <Upload className="h-4 w-4" />
                          {t('uploadPhotos')}
                        </span>
                      </Button>
                    </label>
                    <input
                      id="listing-photos"
                      type="file"
                      className="hidden"
                      onChange={handlePhotoUpload}
                      accept="image/*"
                      multiple
                    />
                    {newListing.photos && newListing.photos.length > 0 && (
                      <div className="grid grid-cols-4 gap-2 mt-2">
                        {newListing.photos.map((photo, idx) => (
                          <div key={idx} className="relative aspect-square">
                            <img src={photo} alt={`Photo ${idx + 1}`} className="w-full h-full object-cover rounded-md" />
                            <Button
                              variant="destructive"
                              size="icon"
                              className="absolute top-1 right-1 h-6 w-6"
                              onClick={() => {
                                const photos = [...(newListing.photos || [])];
                                photos.splice(idx, 1);
                                setNewListing({ ...newListing, photos });
                              }}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <Button className="w-full" onClick={handleSaveListing} data-testid="button-save-listing">
                    {t('saveListing')}
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-2">
              <h2 className="text-2xl font-semibold mb-4 text-foreground">{t('roomListings')}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {listings.map((listing) => (
                  <RoomListingCard 
                    key={listing.id} 
                    listing={listing}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Listing Details Modal */}
      <Dialog open={showDetailsModal} onOpenChange={setShowDetailsModal}>
        <DialogContent className="max-w-2xl" data-testid="dialog-listing-details">
          <DialogHeader>
            <DialogTitle>{selectedListing?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">{t('description')}</h3>
              <p className="text-muted-foreground">{selectedListing?.description}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold mb-1">{t('city')}</h3>
                <p className="text-muted-foreground">{selectedListing?.city}</p>
              </div>
              <div>
                <h3 className="font-semibold mb-1">{t('rentPrice')}</h3>
                <p className="text-muted-foreground">€{selectedListing?.rentPrice}/month</p>
              </div>
            </div>
            {selectedListing?.locationUrl && (
              <Button 
                onClick={handleShowLocation} 
                className="w-full"
                data-testid="button-show-location"
              >
                {t('showLocation')}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Map Modal */}
      {selectedListing?.locationUrl && (
        <MapModal
          open={showMapModal}
          onOpenChange={setShowMapModal}
          locationUrl={selectedListing.locationUrl}
          title={selectedListing.title}
        />
      )}
    </div>
  );
}
