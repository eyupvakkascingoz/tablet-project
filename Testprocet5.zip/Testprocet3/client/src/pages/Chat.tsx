import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { MessageCircle, AlertTriangle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export default function Chat() {
  const { language } = useLanguage();
  const t = useTranslation(language);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">{t('chat')}</h1>
        <p className="text-muted-foreground">{t('chatWarning')}</p>
      </div>

      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>{t('personalChat')}</CardTitle>
            <CardDescription>
              {t('chatWarning')}
            </CardDescription>
          </CardHeader>
          <CardContent className="min-h-[400px] flex flex-col items-center justify-center">
            <div className="text-center text-muted-foreground">
              <MessageCircle className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">{t('comingSoon')}</p>
              <p className="text-sm">{t('chatWarning')}</p>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6">
          <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <p className="text-sm text-foreground text-center flex items-center justify-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              {t('chatWarning')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
