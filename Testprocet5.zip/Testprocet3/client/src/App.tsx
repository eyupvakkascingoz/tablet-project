import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import Navbar from "@/components/Navbar";
import ChatWidget from "@/components/ChatWidget";
import Home from "@/pages/Home";
import Bureaucracy from "@/pages/Bureaucracy";
import Roommates from "@/pages/Roommates";
import Calendar from "@/pages/Calendar";
import Chat from "@/pages/Chat";
import CommunityBoard from "@/pages/CommunityBoard";
import Settings from "@/pages/Settings";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";

function Router() {
  const [location] = useLocation();

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location]);

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/bureaucracy" component={Bureaucracy} />
      <Route path="/roommates" component={Roommates} />
      <Route path="/calendar" component={Calendar} />
      <Route path="/chat" component={Chat} />
      <Route path="/community" component={CommunityBoard} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <LanguageProvider>
          <TooltipProvider>
            <div className="min-h-screen bg-background">
              <Navbar />
              <Router />
            </div>
            <ChatWidget />
            <Toaster />
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
