import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { CODICE_FISCALE_OFFICES, type CodiceFiscaleOffice } from '../../../config/codicefiscale';
import { MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function CodiceFiscaleBooking() {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const isRTL = language === 'ar';
  const { toast } = useToast();

  const [officesOpen, setOfficesOpen] = useState(false);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      return false;
    }
  };

  const openLinkWithFallback = async (url: string) => {
    // Step 1: Try window.open first (works best with direct user gesture)
    const newWindow = window.open(url, '_blank', 'noopener,noreferrer');
    
    if (newWindow) {
      // Successfully opened in new window/tab
      return;
    }

    // Step 2 & 3: If popup blocked, try anchor click AND copy to clipboard
    // We do both because we can't reliably detect if anchor.click() succeeded
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.target = '_blank';
    anchor.rel = 'noopener noreferrer';
    document.body.appendChild(anchor);
    
    // Try clicking the anchor (works in most browsers)
    anchor.click();
    document.body.removeChild(anchor);
    
    // Also try to copy to clipboard as backup
    const copied = await copyToClipboard(url);
    
    // Show appropriate message based on whether clipboard copy succeeded
    toast({
      title: copied ? t('popupBlocked') : t('clipboardFailed'),
      duration: 5000,
    });
  };

  const handleOfficeClick = async (office: CodiceFiscaleOffice, e: React.MouseEvent) => {
    e.stopPropagation();
    await openLinkWithFallback(office.url);
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOfficesOpen(true)}
        data-testid="button-cf-offices"
      >
        <MapPin className="h-4 w-4 mr-2" />
        {t('nearbyOffices')}
      </Button>

      <Dialog open={officesOpen} onOpenChange={setOfficesOpen}>
        <DialogContent className={isRTL ? 'rtl' : ''}>
          <DialogHeader>
            <DialogTitle>{t('nearbyOffices')}</DialogTitle>
            <DialogDescription>
              Agenzia delle Entrate
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {CODICE_FISCALE_OFFICES.map((office) => (
              <div
                key={office.key}
                className="flex items-center justify-between gap-3 p-3 border rounded-lg hover-elevate"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{office.name}</p>
                </div>
                <Button
                  variant="default"
                  size="sm"
                  onClick={(e) => handleOfficeClick(office, e)}
                  data-testid={`button-open-${office.key}`}
                >
                  {t('bookAppointment')}
                </Button>
              </div>
            ))}
          </div>

          <div className="mt-3 p-2 bg-muted/50 rounded-md">
            <p className="text-xs text-muted-foreground">{t('officialSiteWarning')}</p>
          </div>

          <div className="flex justify-end pt-2">
            <Button
              variant="outline"
              onClick={() => setOfficesOpen(false)}
              data-testid="button-close-offices"
            >
              {t('close')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
