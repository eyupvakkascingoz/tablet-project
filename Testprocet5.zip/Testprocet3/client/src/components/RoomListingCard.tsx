import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Euro, Calendar, Home } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export interface RoomListing {
  id: string;
  title: string;
  description: string;
  city: string;
  rentPrice: number;
  locationUrl?: string;
  ownerName: string;
  photos?: string[];
  smoking?: 'allowed' | 'notAllowed';
  pets?: 'allowed' | 'notAllowed';
  furnished?: 'yes' | 'no';
  genderPreference?: 'female' | 'male' | 'none';
  deposit?: number;
  billsIncluded?: boolean;
}

interface RoomListingCardProps {
  listing: RoomListing;
  onViewDetails: (listing: RoomListing) => void;
}

export default function RoomListingCard({ listing, onViewDetails }: RoomListingCardProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);

  return (
    <Card className="hover-elevate" data-testid={`card-listing-${listing.id}`}>
      {listing.photos && listing.photos.length > 0 && (
        <div className="aspect-video w-full overflow-hidden rounded-t-lg">
          <img 
            src={listing.photos[0]} 
            alt={listing.title} 
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0 flex-1">
            <h3 className="font-semibold text-base truncate">{listing.title}</h3>
            <p className="text-sm text-muted-foreground truncate">{listing.ownerName}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3 pb-3">
        <div className="flex items-center gap-2 text-sm">
          <Home className="h-4 w-4 text-muted-foreground" />
          <span className="text-foreground">{listing.city}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Euro className="h-4 w-4 text-muted-foreground" />
          <span className="text-foreground">€{listing.rentPrice}/month</span>
          {listing.deposit && (
            <span className="text-xs text-muted-foreground">+ €{listing.deposit} {t('deposit')}</span>
          )}
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2">{listing.description}</p>
        
        <div className="flex flex-wrap gap-1">
          {listing.smoking === 'allowed' && (
            <Badge variant="outline" className="text-xs">{t('smokingAllowed')}</Badge>
          )}
          {listing.smoking === 'notAllowed' && (
            <Badge variant="outline" className="text-xs">{t('noSmoking')}</Badge>
          )}
          {listing.pets === 'allowed' && (
            <Badge variant="outline" className="text-xs">{t('petFriendly')}</Badge>
          )}
          {listing.pets === 'notAllowed' && (
            <Badge variant="outline" className="text-xs">{t('noPets')}</Badge>
          )}
          {listing.furnished === 'yes' && (
            <Badge variant="outline" className="text-xs">{t('furnished')}</Badge>
          )}
          {listing.furnished === 'no' && (
            <Badge variant="outline" className="text-xs">{t('unfurnished')}</Badge>
          )}
          {listing.billsIncluded && (
            <Badge variant="outline" className="text-xs">{t('billsIncluded')}</Badge>
          )}
          {listing.genderPreference === 'female' && (
            <Badge variant="outline" className="text-xs">{t('femaleOnly')}</Badge>
          )}
          {listing.genderPreference === 'male' && (
            <Badge variant="outline" className="text-xs">{t('maleOnly')}</Badge>
          )}
          {listing.locationUrl && (
            <Badge variant="outline" className="text-xs" data-testid={`badge-location-${listing.id}`}>
              <MapPin className="h-3 w-3 mr-1" />
              {t('location')}
            </Badge>
          )}
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          variant="outline" 
          className="w-full" 
          onClick={() => onViewDetails(listing)}
          data-testid={`button-view-details-${listing.id}`}
        >
          {t('viewDetails')}
        </Button>
      </CardFooter>
    </Card>
  );
}
