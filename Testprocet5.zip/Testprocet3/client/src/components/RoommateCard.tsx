import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Home, Euro, Dog, Cigarette, Sparkles, Volume2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export interface RoommateProfile {
  id: string;
  name: string;
  city: string;
  university: string;
  budgetMin: number;
  budgetMax: number;
  pets: boolean;
  smoker: boolean;
  cleanliness: number;
  noiseTolerance: number;
  matchPercentage?: number;
}

interface RoommateCardProps {
  profile: RoommateProfile;
}

export default function RoommateCard({ profile }: RoommateCardProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);

  const getColorClass = (percentage: number) => {
    if (percentage >= 75) return 'bg-success text-success-foreground';
    if (percentage >= 50) return 'bg-warning text-warning-foreground';
    return 'bg-destructive text-destructive-foreground';
  };

  const initials = profile.name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card className="hover-elevate" data-testid={`card-roommate-${profile.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3 flex-1">
            <Avatar className="h-12 w-12">
              <AvatarFallback className="bg-primary text-primary-foreground">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <h3 className="font-semibold text-base truncate">{profile.name}</h3>
              <p className="text-sm text-muted-foreground truncate">{profile.university}</p>
            </div>
          </div>
          {profile.matchPercentage !== undefined && (
            <Badge className={`${getColorClass(profile.matchPercentage)} text-sm font-bold`}>
              {profile.matchPercentage}%
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3 pb-3">
        <div className="flex items-center gap-2 text-sm">
          <Home className="h-4 w-4 text-muted-foreground" />
          <span className="text-foreground">{profile.city}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Euro className="h-4 w-4 text-muted-foreground" />
          <span className="text-foreground">
            €{profile.budgetMin} - €{profile.budgetMax}/month
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="gap-1">
            <Dog className="h-3 w-3" />
            {profile.pets ? t('yes') : t('no')}
          </Badge>
          <Badge variant="outline" className="gap-1">
            <Cigarette className="h-3 w-3" />
            {profile.smoker ? t('yes') : t('no')}
          </Badge>
          <Badge variant="outline" className="gap-1">
            <Sparkles className="h-3 w-3" />
            {profile.cleanliness}/5
          </Badge>
          <Badge variant="outline" className="gap-1">
            <Volume2 className="h-3 w-3" />
            {profile.noiseTolerance}/5
          </Badge>
        </div>
      </CardContent>
      <CardFooter>
        <Button variant="outline" className="w-full" disabled data-testid={`button-contact-${profile.id}`}>
          {t('contact')}
        </Button>
      </CardFooter>
    </Card>
  );
}
